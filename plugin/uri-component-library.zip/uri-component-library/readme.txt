=== URI Component Library ===

Contributors: Brandon Fuller
Tags: plugins
Requires at least: 4.0
Tested up to: 4.7
Stable tag: 1.0
Build: 17.1114

Component Library

== Description ==

Add the component library, including shortcodes, to WordPress

TBD